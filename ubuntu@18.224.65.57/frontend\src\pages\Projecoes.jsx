import Layout from "../components/Layout";

export default function Projecoes() {
  return (
    <Layout ativo="Projeções">
      <h1 className="text-xl font-bold">Página de Projeções</h1>
      <p>Simulações e projeções financeiras vão vir aqui.</p>
    </Layout>
  );
}
