import Layout from "../components/Layout";

export default function Consultas() {
  return (
    <Layout ativo="Consultas">
      <h1 className="text-xl font-bold">Página de Consultas</h1>
      <p>Consulta de dados por voz ou texto em breve.</p>
    </Layout>
  );
}
